var _chi_sq_8h =
[
    [ "CChiSqApp", "class_c_chi_sq_app.html", "class_c_chi_sq_app" ],
    [ "global_rne", "_chi_sq_8h.html#af89cdd9a335ebe8162feff36bcfbe4ff", null ],
    [ "theApp", "_chi_sq_8h.html#a461f6c22acc5944b1da5f22f3c2212b1", null ]
];