var framework_8h =
[
    [ "_AFX_ALL_WARNINGS", "framework_8h.html#ab5fd5e01d3484ef3116a878a65b82980", null ],
    [ "_ATL_CSTRING_EXPLICIT_CONSTRUCTORS", "framework_8h.html#a137e19a46f145129447af81af06def9f", null ],
    [ "VC_EXTRALEAN", "framework_8h.html#a0172fbace36625330d5f0f163a1ddc1a", null ]
];