var class_inverse_function_d_g =
[
    [ "InverseFunctionDG", "class_inverse_function_d_g.html#a4a2c9257d6929489861012375c11d162", null ],
    [ "GetRandomValue", "class_inverse_function_d_g.html#a40326322c1344a2bd40a8c0e1886bc3b", null ],
    [ "_marked_table", "class_inverse_function_d_g.html#a760427b70b11e93be9951267b54ccc5d", null ]
];