var searchData=
[
  ['framework_2eh_0',['framework.h',['../framework_8h.html',1,'']]]
];
