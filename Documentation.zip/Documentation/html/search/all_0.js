var searchData=
[
  ['_5faccumulated_5fprobabilities_0',['_accumulated_probabilities',['../class_dichotomy_d_g.html#a6aa142395a4c3866d0559775e7e414e8',1,'DichotomyDG']]],
  ['_5fcriterion_1',['_criterion',['../class_chi_square.html#af5bef0e14b6ddc09013da0ae87e0f15a',1,'ChiSquare']]],
  ['_5fdistribution_2',['_distribution',['../class_discrete_generator.html#ad9638c253a27017aa1eced6065bbbb25',1,'DiscreteGenerator']]],
  ['_5fexpected_3',['_expected',['../class_chi_square.html#a6a2aef98552fae7e346764a00c2db338',1,'ChiSquare']]],
  ['_5fgenerator_5ftype_4',['_generator_type',['../class_discrete_generator.html#a6249de447e6a9d4a71c55a84ae429bad',1,'DiscreteGenerator']]],
  ['_5fmarked_5ftable_5',['_marked_table',['../class_inverse_function_d_g.html#a760427b70b11e93be9951267b54ccc5d',1,'InverseFunctionDG']]],
  ['_5fobserved_6',['_observed',['../class_chi_square.html#aeae734fd8e59c93fd52618771688a83a',1,'ChiSquare']]],
  ['_5fp_5fvalue_7',['_p_value',['../class_chi_square.html#af39a56381a5b9287350ba45e571b85c7',1,'ChiSquare']]],
  ['_5fprobabilities_8',['_probabilities',['../class_distribution.html#abd6b5beebee9f61e58d2574330339328',1,'Distribution']]],
  ['_5fsample_9',['_sample',['../class_discrete_generator.html#a3e8fcd3941c6cba93f97c215f0e1fb88',1,'DiscreteGenerator']]],
  ['_5fsample_5fsize_10',['_sample_size',['../class_discrete_generator.html#a4d2d4a0360547a2ddf137ebc282d4e9f',1,'DiscreteGenerator']]],
  ['_5fstates_11',['_states',['../class_distribution.html#a1e16078d836e2ab7ea31d30541dc16b0',1,'Distribution']]]
];
