var searchData=
[
  ['chi_2dsquare_0',['Chi-Square',['../index.html',1,'']]]
];
