var searchData=
[
  ['vc_5fextralean_0',['VC_EXTRALEAN',['../framework_8h.html#a0172fbace36625330d5f0f163a1ddc1a',1,'framework.h']]]
];
