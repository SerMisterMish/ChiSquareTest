var searchData=
[
  ['getname_0',['GetName',['../class_discrete_distribution.html#a40d46ba220ecee4bc8f88a1b383d7842',1,'DiscreteDistribution::GetName()'],['../class_distribution.html#a777fed0e9241a5deb3be87545655e4a5',1,'Distribution::GetName()']]],
  ['getrandomvalue_1',['GetRandomValue',['../class_dichotomy_d_g.html#aa402113e1d02ec16296cf8aded3df1bc',1,'DichotomyDG::GetRandomValue()'],['../class_discrete_generator.html#a07ea6449edfe6cc78672004bb950509c',1,'DiscreteGenerator::GetRandomValue()'],['../class_inverse_function_d_g.html#a40326322c1344a2bd40a8c0e1886bc3b',1,'InverseFunctionDG::GetRandomValue()']]]
];
