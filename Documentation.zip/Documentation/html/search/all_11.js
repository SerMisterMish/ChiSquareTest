var searchData=
[
  ['_7ecchisqdoc_0',['~CChiSqDoc',['../class_c_chi_sq_doc.html#a20bed67e6b4fa8a9afe58ef59a945289',1,'CChiSqDoc']]],
  ['_7ecchisqview_1',['~CChiSqView',['../class_c_chi_sq_view.html#a980385dfa72465964d716f6e856b59d1',1,'CChiSqView']]],
  ['_7echisquare_2',['~ChiSquare',['../class_chi_square.html#aee60aad4504672177ca25a5bedea8641',1,'ChiSquare']]],
  ['_7ecmainframe_3',['~CMainFrame',['../class_c_main_frame.html#a8ae555f23fdf97edb4feb4d3e1bfa4ee',1,'CMainFrame']]],
  ['_7edichotomydg_4',['~DichotomyDG',['../class_dichotomy_d_g.html#a197fa54b111c4c5641bb9c8e11114bbb',1,'DichotomyDG']]],
  ['_7ediscretedistribution_5',['~DiscreteDistribution',['../class_discrete_distribution.html#a868dad4c501d0a2c72a61f039477e666',1,'DiscreteDistribution']]],
  ['_7ediscretegenerator_6',['~DiscreteGenerator',['../class_discrete_generator.html#a59c2ebc02d99a21bf90d2b09d24990c8',1,'DiscreteGenerator']]],
  ['_7edistribution_7',['~Distribution',['../class_distribution.html#a0b585e4cc1a10cf3628e27e8a81c9c72',1,'Distribution']]],
  ['_7einversefunctiondg_8',['~InverseFunctionDG',['../class_inverse_function_d_g.html#ad60ba845c85fc27d4722d814f81262eb',1,'InverseFunctionDG']]],
  ['_7esettingsdialog_9',['~SettingsDialog',['../class_settings_dialog.html#ac48f54d4472902be0a3845a69167f068',1,'SettingsDialog']]]
];
