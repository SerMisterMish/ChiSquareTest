var searchData=
[
  ['hist_0',['HIST',['../class_c_chi_sq_doc.html#a64430c234cb9faa01a4fc9e56f0320c0a883f629b9ddb1c7038c82064f3aefd82',1,'CChiSqDoc']]]
];
