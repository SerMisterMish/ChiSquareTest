var searchData=
[
  ['calculatestatistic_0',['CalculateStatistic',['../class_chi_square.html#aac9adf622ec2286259de05418df6f769',1,'ChiSquare']]],
  ['chi_2dsquare_1',['Chi-Square',['../index.html',1,'']]],
  ['chisquare_2',['ChiSquare',['../class_chi_square.html',1,'ChiSquare'],['../class_chi_square.html#a98fd00dd36100f6ea986d804c6d0609d',1,'ChiSquare::ChiSquare(const DiscreteGenerator *observed_frequencies_generator, DiscreteDistribution expected_distribution)'],['../class_chi_square.html#affd73d7aefe490cdb21c274ef6a8ef9b',1,'ChiSquare::ChiSquare(const long long *observed_sample, const double *expected_probabilities, size_t states_number)'],['../class_chi_square.html#a59a2f814083fced4453cfc493b23a7db',1,'ChiSquare::ChiSquare(const long long *observed_sample, DiscreteDistribution expected_distribution)'],['../class_chi_square.html#a93a880cd881830d656e479379b162cf6',1,'ChiSquare::ChiSquare(const DiscreteGenerator *observed_frequencies_generator, const double *expected_probabilities)']]]
];
