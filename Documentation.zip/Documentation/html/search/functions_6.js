var searchData=
[
  ['precreatewindow_0',['PreCreateWindow',['../class_c_chi_sq_view.html#ae605621bdaf12c5b407987f8ac5eb59a',1,'CChiSqView::PreCreateWindow()'],['../class_c_main_frame.html#a549bf677c955c2898c3c683321633c16',1,'CMainFrame::PreCreateWindow()']]],
  ['preloadstate_1',['PreLoadState',['../class_c_chi_sq_app.html#a84542812f8c4f4e93c1bbaae46f0c314',1,'CChiSqApp']]]
];
