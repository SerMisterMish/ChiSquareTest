var searchData=
[
  ['p_5fvalue_5fsample_0',['p_value_sample',['../class_c_chi_sq_doc.html#aa77428373375760dcc57b402f808c86d',1,'CChiSqDoc']]],
  ['p_5fvalue_5fsample_5fsize_1',['p_value_sample_size',['../class_c_chi_sq_doc.html#aeeeaf804c9c069641f5ea4c60ff028c1',1,'CChiSqDoc']]],
  ['p_5fvalue_5fsplit_5fsize_2',['p_value_split_size',['../class_c_chi_sq_doc.html#a89caed29a8f4b3315f731e7495c09343',1,'CChiSqDoc']]],
  ['pch_2ecpp_3',['pch.cpp',['../pch_8cpp.html',1,'']]],
  ['pch_2eh_4',['pch.h',['../pch_8h.html',1,'']]],
  ['power_5flevel_5fon_5fsample_5fsize_5',['POWER_LEVEL_ON_SAMPLE_SIZE',['../class_c_chi_sq_doc.html#a64430c234cb9faa01a4fc9e56f0320c0a26b8cd5e6ee8885de6c4db9c97fc0e68',1,'CChiSqDoc']]],
  ['power_5flevels_6',['power_levels',['../class_c_chi_sq_doc.html#ac9044a097b58a324f5a6f879b35e44f5',1,'CChiSqDoc']]],
  ['power_5ftest_5fmax_7',['power_test_max',['../class_c_chi_sq_doc.html#a04147544b06b469497f970ca80d9a51d',1,'CChiSqDoc']]],
  ['power_5ftest_5fmin_8',['power_test_min',['../class_c_chi_sq_doc.html#a9e7e62101ac3a7eb87fb7bd9e66cd09a',1,'CChiSqDoc']]],
  ['power_5ftest_5fsl_9',['power_test_sl',['../class_c_chi_sq_doc.html#ae9f04c1154d4082c274f8342a5da3b3c',1,'CChiSqDoc']]],
  ['precreatewindow_10',['PreCreateWindow',['../class_c_chi_sq_view.html#ae605621bdaf12c5b407987f8ac5eb59a',1,'CChiSqView::PreCreateWindow()'],['../class_c_main_frame.html#a549bf677c955c2898c3c683321633c16',1,'CMainFrame::PreCreateWindow()']]],
  ['preloadstate_11',['PreLoadState',['../class_c_chi_sq_app.html#a84542812f8c4f4e93c1bbaae46f0c314',1,'CChiSqApp']]],
  ['pvdist_12',['PVDIST',['../class_c_chi_sq_doc.html#a64430c234cb9faa01a4fc9e56f0320c0aabd0288c33cdc34dcf434b964e44d223',1,'CChiSqDoc']]]
];
