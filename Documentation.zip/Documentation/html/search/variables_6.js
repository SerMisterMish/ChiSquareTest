var searchData=
[
  ['p_5fvalue_5fsample_0',['p_value_sample',['../class_c_chi_sq_doc.html#aa77428373375760dcc57b402f808c86d',1,'CChiSqDoc']]],
  ['p_5fvalue_5fsample_5fsize_1',['p_value_sample_size',['../class_c_chi_sq_doc.html#aeeeaf804c9c069641f5ea4c60ff028c1',1,'CChiSqDoc']]],
  ['p_5fvalue_5fsplit_5fsize_2',['p_value_split_size',['../class_c_chi_sq_doc.html#a89caed29a8f4b3315f731e7495c09343',1,'CChiSqDoc']]],
  ['power_5flevels_3',['power_levels',['../class_c_chi_sq_doc.html#ac9044a097b58a324f5a6f879b35e44f5',1,'CChiSqDoc']]],
  ['power_5ftest_5fmax_4',['power_test_max',['../class_c_chi_sq_doc.html#a04147544b06b469497f970ca80d9a51d',1,'CChiSqDoc']]],
  ['power_5ftest_5fmin_5',['power_test_min',['../class_c_chi_sq_doc.html#a9e7e62101ac3a7eb87fb7bd9e66cd09a',1,'CChiSqDoc']]],
  ['power_5ftest_5fsl_6',['power_test_sl',['../class_c_chi_sq_doc.html#ae9f04c1154d4082c274f8342a5da3b3c',1,'CChiSqDoc']]]
];
