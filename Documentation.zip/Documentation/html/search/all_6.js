var searchData=
[
  ['setprobabilities_0',['SetProbabilities',['../class_distribution.html#a81e0678a44841f92129ee86690a6bd08',1,'Distribution']]],
  ['setprobabilitiesm_1',['SetProbabilitiesM',['../class_distribution.html#a119c94698a9f6d4c0a9c96f457930342',1,'Distribution']]],
  ['setprobabilitiessamesize_2',['SetProbabilitiesSameSize',['../class_distribution.html#af4ab6b2c594945b60518cc8d82a858da',1,'Distribution']]],
  ['setprobabilitiessamesizem_3',['SetProbabilitiesSameSizeM',['../class_distribution.html#a1e45d868f8d4c2a2cdda2e201116d4d3',1,'Distribution']]],
  ['simulate_4',['Simulate',['../class_discrete_generator.html#a42a925faa193756bc7b05ed22a49ae77',1,'DiscreteGenerator']]]
];
