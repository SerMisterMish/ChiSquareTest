var searchData=
[
  ['_5fafx_5fall_5fwarnings_0',['_AFX_ALL_WARNINGS',['../framework_8h.html#ab5fd5e01d3484ef3116a878a65b82980',1,'framework.h']]],
  ['_5fatl_5fcstring_5fexplicit_5fconstructors_1',['_ATL_CSTRING_EXPLICIT_CONSTRUCTORS',['../framework_8h.html#a137e19a46f145129447af81af06def9f',1,'framework.h']]]
];
