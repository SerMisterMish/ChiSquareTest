var searchData=
[
  ['has_5fgenerator_0',['has_generator',['../class_chi_square.html#a222687e5a60943ce929eeb4dc4ef6390',1,'ChiSquare']]]
];
