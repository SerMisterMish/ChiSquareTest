var searchData=
[
  ['loadcustomstate_0',['LoadCustomState',['../class_c_chi_sq_app.html#a538f718290813a74f7f98dc4c7121e82',1,'CChiSqApp']]],
  ['loadframe_1',['LoadFrame',['../class_c_main_frame.html#a5079f9fe53772359e3d7b2ecaa75f094',1,'CMainFrame']]]
];
