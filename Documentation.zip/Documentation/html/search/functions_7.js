var searchData=
[
  ['savecustomstate_0',['SaveCustomState',['../class_c_chi_sq_app.html#a2921b4afc27bc1e65bcd549ae2e98706',1,'CChiSqApp']]],
  ['serialize_1',['Serialize',['../class_c_chi_sq_doc.html#a367f7921adb0e89d5aa4164eeb69b05f',1,'CChiSqDoc']]],
  ['setprobabilities_2',['SetProbabilities',['../class_distribution.html#a81e0678a44841f92129ee86690a6bd08',1,'Distribution']]],
  ['setprobabilitiesm_3',['SetProbabilitiesM',['../class_distribution.html#a119c94698a9f6d4c0a9c96f457930342',1,'Distribution']]],
  ['setprobabilitiessamesize_4',['SetProbabilitiesSameSize',['../class_distribution.html#af4ab6b2c594945b60518cc8d82a858da',1,'Distribution']]],
  ['setprobabilitiessamesizem_5',['SetProbabilitiesSameSizeM',['../class_distribution.html#a1e45d868f8d4c2a2cdda2e201116d4d3',1,'Distribution']]],
  ['setsample_6',['SetSample',['../class_discrete_generator.html#a55b62ec77b89d5d6b2f7590576b152db',1,'DiscreteGenerator']]],
  ['setsamplesize_7',['SetSampleSize',['../class_discrete_generator.html#ac49c8c6108febc5ac492bacc6842fb1e',1,'DiscreteGenerator']]],
  ['setstatesnumber_8',['SetStatesNumber',['../class_distribution.html#a7b822a3ce458953bddb96e1ab04f8410',1,'Distribution']]],
  ['settingsdialog_9',['SettingsDialog',['../class_settings_dialog.html#a434848f3d47d154277f19b852ebdf0b2',1,'SettingsDialog']]],
  ['simulate_10',['Simulate',['../class_discrete_generator.html#a42a925faa193756bc7b05ed22a49ae77',1,'DiscreteGenerator']]]
];
