var searchData=
[
  ['generation_5fmethod_0',['generation_method',['../class_c_chi_sq_doc.html#a22f0e8a02ea48e6f12c6ce743eed1a1e',1,'CChiSqDoc']]],
  ['generator_1',['generator',['../class_c_chi_sq_doc.html#ae8268f42956bf870c3c9b72e933a2f2d',1,'CChiSqDoc']]],
  ['global_5frne_2',['global_rne',['../_chi_sq_8h.html#af89cdd9a335ebe8162feff36bcfbe4ff',1,'ChiSq.h']]]
];
