var searchData=
[
  ['none_0',['NONE',['../class_c_chi_sq_doc.html#a64430c234cb9faa01a4fc9e56f0320c0ab50339a10e1de285ac99d4c3990b8693',1,'CChiSqDoc']]]
];
