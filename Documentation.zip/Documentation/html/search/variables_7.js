var searchData=
[
  ['sample_5fsize_0',['sample_size',['../class_c_chi_sq_doc.html#a640d6dd1ea1b08c51dcc25bdf4439d70',1,'CChiSqDoc']]],
  ['settings_5fapplied_1',['settings_applied',['../class_c_chi_sq_doc.html#ac81cb1929524b76b207440aae9acf74b',1,'CChiSqDoc']]],
  ['states_2',['states',['../class_c_chi_sq_doc.html#a3ad3a6a52d8b4edf395d4333b08e0454',1,'CChiSqDoc']]]
];
