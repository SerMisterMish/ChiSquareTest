var searchData=
[
  ['settingsdialog_2ecpp_0',['SettingsDialog.cpp',['../_settings_dialog_8cpp.html',1,'']]],
  ['settingsdialog_2eh_1',['SettingsDialog.h',['../_settings_dialog_8h.html',1,'']]]
];
