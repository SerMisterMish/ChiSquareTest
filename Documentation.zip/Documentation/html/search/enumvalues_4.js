var searchData=
[
  ['power_5flevel_5fon_5fsample_5fsize_0',['POWER_LEVEL_ON_SAMPLE_SIZE',['../class_c_chi_sq_doc.html#a64430c234cb9faa01a4fc9e56f0320c0a26b8cd5e6ee8885de6c4db9c97fc0e68',1,'CChiSqDoc']]],
  ['pvdist_1',['PVDIST',['../class_c_chi_sq_doc.html#a64430c234cb9faa01a4fc9e56f0320c0aabd0288c33cdc34dcf434b964e44d223',1,'CChiSqDoc']]]
];
