var searchData=
[
  ['targetver_2eh_0',['targetver.h',['../targetver_8h.html',1,'']]],
  ['theapp_1',['theApp',['../_chi_sq_8cpp.html#a461f6c22acc5944b1da5f22f3c2212b1',1,'theApp():&#160;ChiSq.cpp'],['../_chi_sq_8h.html#a461f6c22acc5944b1da5f22f3c2212b1',1,'theApp():&#160;ChiSq.cpp']]]
];
