var searchData=
[
  ['settingsdialog_0',['SettingsDialog',['../class_settings_dialog.html',1,'']]]
];
