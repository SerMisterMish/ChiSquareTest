var searchData=
[
  ['chisquare_0',['ChiSquare',['../class_chi_square.html',1,'']]]
];
