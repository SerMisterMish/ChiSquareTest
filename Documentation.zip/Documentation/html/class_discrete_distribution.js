var class_discrete_distribution =
[
    [ "DiscreteDistribution", "class_discrete_distribution.html#a6b96c7abcb9783a960896ec9d673fbd6", null ],
    [ "DiscreteDistribution", "class_discrete_distribution.html#a811962f69a3d0b56ab241d2d33d5c82e", null ],
    [ "DiscreteDistribution", "class_discrete_distribution.html#a0188f9de74147a75de5665166853e28f", null ],
    [ "GetName", "class_discrete_distribution.html#a40d46ba220ecee4bc8f88a1b383d7842", null ]
];