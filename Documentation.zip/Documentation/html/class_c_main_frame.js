var class_c_main_frame =
[
    [ "CMainFrame", "class_c_main_frame.html#a12cc0b54ac36d30c03df2191d53c2889", null ],
    [ "~CMainFrame", "class_c_main_frame.html#a8ae555f23fdf97edb4feb4d3e1bfa4ee", null ],
    [ "LoadFrame", "class_c_main_frame.html#a5079f9fe53772359e3d7b2ecaa75f094", null ],
    [ "OnApplicationLook", "class_c_main_frame.html#af1d93af581b05ad718a9076042a9408d", null ],
    [ "OnCreate", "class_c_main_frame.html#a48666466fd37412fcaeff75c3b12e0ed", null ],
    [ "OnToolbarCreateNew", "class_c_main_frame.html#a6088aa727bb4218f7fd40b494a248145", null ],
    [ "OnUpdateApplicationLook", "class_c_main_frame.html#aa6a07aed318ec6813316612c272ba8c1", null ],
    [ "OnViewCustomize", "class_c_main_frame.html#a4283b14a42dd393342593c495083777f", null ],
    [ "PreCreateWindow", "class_c_main_frame.html#a549bf677c955c2898c3c683321633c16", null ],
    [ "m_UserImages", "class_c_main_frame.html#af9bce613ed89bfdc4175d38acf58f4cf", null ],
    [ "m_wndMenuBar", "class_c_main_frame.html#a6795bad4fe111fe3c634dcafb59de402", null ],
    [ "m_wndStatusBar", "class_c_main_frame.html#a5842bded00e9137fbbf77343b99863be", null ],
    [ "m_wndToolBar", "class_c_main_frame.html#ac8558942627d1502b5095e736840a1f3", null ]
];