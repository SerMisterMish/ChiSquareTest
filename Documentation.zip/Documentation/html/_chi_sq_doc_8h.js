var _chi_sq_doc_8h =
[
    [ "CChiSqDoc", "class_c_chi_sq_doc.html", "class_c_chi_sq_doc" ]
];