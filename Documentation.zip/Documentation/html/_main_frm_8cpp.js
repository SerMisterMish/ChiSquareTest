var _main_frm_8cpp =
[
    [ "iMaxUserToolbars", "_main_frm_8cpp.html#abf855455b7b0d4ea11130607126c2fa0", null ],
    [ "uiFirstUserToolBarId", "_main_frm_8cpp.html#ac26fb356b19501050f97f01d94ce8420", null ],
    [ "uiLastUserToolBarId", "_main_frm_8cpp.html#a15d7db714bae16d90e4402c87a810d22", null ]
];