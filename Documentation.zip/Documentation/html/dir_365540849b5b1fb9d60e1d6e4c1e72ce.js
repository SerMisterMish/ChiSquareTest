var dir_365540849b5b1fb9d60e1d6e4c1e72ce =
[
    [ "ChiSquare.cpp", "_chi_square_8cpp_source.html", null ],
    [ "ChiSquare.h", "_chi_square_8h_source.html", null ],
    [ "DichotomyDG.cpp", "_dichotomy_d_g_8cpp_source.html", null ],
    [ "DichotomyDG.h", "_dichotomy_d_g_8h_source.html", null ],
    [ "DiscreteDistribution.cpp", "_discrete_distribution_8cpp_source.html", null ],
    [ "DiscreteDistribution.h", "_discrete_distribution_8h_source.html", null ],
    [ "DiscreteGenerator.cpp", "_discrete_generator_8cpp_source.html", null ],
    [ "DiscreteGenerator.h", "_discrete_generator_8h_source.html", null ],
    [ "Distribution.cpp", "_distribution_8cpp_source.html", null ],
    [ "Distribution.h", "_distribution_8h_source.html", null ],
    [ "InverseFunctionDG.cpp", "_inverse_function_d_g_8cpp_source.html", null ],
    [ "InverseFunctionDG.h", "_inverse_function_d_g_8h_source.html", null ],
    [ "pch.cpp", "pch_8cpp_source.html", null ],
    [ "pch.h", "pch_8h_source.html", null ]
];