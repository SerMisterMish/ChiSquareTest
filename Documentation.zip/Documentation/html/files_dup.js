var files_dup =
[
    [ "ChiSq", "dir_d98f5c937d46f962460f2b4a5df8f6e1.html", "dir_d98f5c937d46f962460f2b4a5df8f6e1" ]
];