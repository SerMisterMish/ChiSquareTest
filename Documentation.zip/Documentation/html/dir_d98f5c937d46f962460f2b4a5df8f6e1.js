var dir_d98f5c937d46f962460f2b4a5df8f6e1 =
[
    [ "ChiSquare.h", "_chi_square_8h_source.html", null ],
    [ "DichotomyDG.h", "_dichotomy_d_g_8h_source.html", null ],
    [ "DiscreteDistribution.h", "_discrete_distribution_8h_source.html", null ],
    [ "DiscreteGenerator.h", "_discrete_generator_8h_source.html", null ],
    [ "Distribution.h", "_distribution_8h_source.html", null ],
    [ "InverseFunctionDG.h", "_inverse_function_d_g_8h_source.html", null ],
    [ "pch.h", "pch_8h_source.html", null ]
];