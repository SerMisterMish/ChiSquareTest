var _settings_dialog_8cpp =
[
    [ "GetRandomDistribution", "_settings_dialog_8cpp.html#a7761ebcb30d52df4c5a262ab4ac6d3c9", null ]
];