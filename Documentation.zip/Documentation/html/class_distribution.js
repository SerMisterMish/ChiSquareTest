var class_distribution =
[
    [ "Distribution", "class_distribution.html#a3e777b59933025dd040ee58e4d182e7e", null ],
    [ "Distribution", "class_distribution.html#a1dd88c7ea5d42d86fabf99888bae4ab2", null ],
    [ "Distribution", "class_distribution.html#a331a258eb906bd30c811ba2b369d4e64", null ],
    [ "GetName", "class_distribution.html#a777fed0e9241a5deb3be87545655e4a5", null ],
    [ "SetProbabilities", "class_distribution.html#a81e0678a44841f92129ee86690a6bd08", null ],
    [ "SetProbabilitiesM", "class_distribution.html#a119c94698a9f6d4c0a9c96f457930342", null ],
    [ "SetProbabilitiesSameSize", "class_distribution.html#af4ab6b2c594945b60518cc8d82a858da", null ],
    [ "SetProbabilitiesSameSizeM", "class_distribution.html#a1e45d868f8d4c2a2cdda2e201116d4d3", null ],
    [ "_probabilities", "class_distribution.html#abd6b5beebee9f61e58d2574330339328", null ],
    [ "_states", "class_distribution.html#a1e16078d836e2ab7ea31d30541dc16b0", null ]
];