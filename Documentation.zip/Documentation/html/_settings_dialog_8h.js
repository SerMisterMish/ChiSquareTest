var _settings_dialog_8h =
[
    [ "SettingsDialog", "class_settings_dialog.html", "class_settings_dialog" ]
];