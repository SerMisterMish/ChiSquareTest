var _chi_square_8cpp =
[
    [ "criterion", "_chi_square_8cpp.html#ae55227f02866e91fdf7f68d4e29bc150", null ],
    [ "group_sample", "_chi_square_8cpp.html#a401352b10453784eb6fbd2d2eee3618d", null ]
];