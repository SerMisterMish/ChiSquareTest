var class_chi_square =
[
    [ "ChiSquare", "class_chi_square.html#a98fd00dd36100f6ea986d804c6d0609d", null ],
    [ "ChiSquare", "class_chi_square.html#affd73d7aefe490cdb21c274ef6a8ef9b", null ],
    [ "ChiSquare", "class_chi_square.html#a59a2f814083fced4453cfc493b23a7db", null ],
    [ "ChiSquare", "class_chi_square.html#a93a880cd881830d656e479379b162cf6", null ],
    [ "CalculateStatistic", "class_chi_square.html#aac9adf622ec2286259de05418df6f769", null ],
    [ "_criterion", "class_chi_square.html#af5bef0e14b6ddc09013da0ae87e0f15a", null ],
    [ "_expected", "class_chi_square.html#a6a2aef98552fae7e346764a00c2db338", null ],
    [ "_observed", "class_chi_square.html#aeae734fd8e59c93fd52618771688a83a", null ],
    [ "_p_value", "class_chi_square.html#af39a56381a5b9287350ba45e571b85c7", null ],
    [ "has_generator", "class_chi_square.html#a222687e5a60943ce929eeb4dc4ef6390", null ]
];