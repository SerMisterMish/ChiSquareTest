var _chi_sq_8cpp =
[
    [ "CAboutDlg", "class_c_about_dlg.html", "class_c_about_dlg" ],
    [ "global_rne", "_chi_sq_8cpp.html#a549384b5858c218c095216dc71d5c950", null ],
    [ "theApp", "_chi_sq_8cpp.html#a461f6c22acc5944b1da5f22f3c2212b1", null ]
];