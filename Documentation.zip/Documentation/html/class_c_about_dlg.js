var class_c_about_dlg =
[
    [ "CAboutDlg", "class_c_about_dlg.html#a2482a6b74da28cfc05a47a5cea4a1ac6", null ],
    [ "DoDataExchange", "class_c_about_dlg.html#ab83db7484fec957282d7d5a21aed4df4", null ]
];