var class_c_chi_sq_view =
[
    [ "CChiSqView", "class_c_chi_sq_view.html#a10489b08b8f03ce39e380705d801a603", null ],
    [ "~CChiSqView", "class_c_chi_sq_view.html#a980385dfa72465964d716f6e856b59d1", null ],
    [ "DrawHist", "class_c_chi_sq_view.html#a5c8213e205bc4ffbcecdb120105a360e", null ],
    [ "DrawPowerLevelOnSampleSize", "class_c_chi_sq_view.html#af2553a83e7194c69b1153ad62c1736d3", null ],
    [ "DrawPVDF", "class_c_chi_sq_view.html#a4b566648d6366fbba21236683477017c", null ],
    [ "GetDocument", "class_c_chi_sq_view.html#a585d44989f06c2dc8341e61689693787", null ],
    [ "OnContextMenu", "class_c_chi_sq_view.html#a8de025d76b890f889214bd9f5ea52efb", null ],
    [ "OnDraw", "class_c_chi_sq_view.html#a693c0fcc6b60e6a89ee3db85a16e3ef9", null ],
    [ "OnFilePrintPreview", "class_c_chi_sq_view.html#ada474797c2eb91806cf4d6a8820118d0", null ],
    [ "OnRButtonUp", "class_c_chi_sq_view.html#a89f8b36c4eed1fd6f2053357c296d8d0", null ],
    [ "PreCreateWindow", "class_c_chi_sq_view.html#ae605621bdaf12c5b407987f8ac5eb59a", null ]
];