var annotated_dup =
[
    [ "ChiSquare", "class_chi_square.html", "class_chi_square" ],
    [ "DichotomyDG", "class_dichotomy_d_g.html", "class_dichotomy_d_g" ],
    [ "DiscreteDistribution", "class_discrete_distribution.html", "class_discrete_distribution" ],
    [ "DiscreteGenerator", "class_discrete_generator.html", "class_discrete_generator" ],
    [ "Distribution", "class_distribution.html", "class_distribution" ],
    [ "InverseFunctionDG", "class_inverse_function_d_g.html", "class_inverse_function_d_g" ]
];