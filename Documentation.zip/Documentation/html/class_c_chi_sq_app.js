var class_c_chi_sq_app =
[
    [ "CChiSqApp", "class_c_chi_sq_app.html#adb019e41dff5124321af74d308734b68", null ],
    [ "InitInstance", "class_c_chi_sq_app.html#a565d72348a0602885d1a76dcfff27533", null ],
    [ "LoadCustomState", "class_c_chi_sq_app.html#a538f718290813a74f7f98dc4c7121e82", null ],
    [ "OnAppAbout", "class_c_chi_sq_app.html#ae3e1951395463fa56591de07cc2b3707", null ],
    [ "PreLoadState", "class_c_chi_sq_app.html#a84542812f8c4f4e93c1bbaae46f0c314", null ],
    [ "SaveCustomState", "class_c_chi_sq_app.html#a2921b4afc27bc1e65bcd549ae2e98706", null ],
    [ "m_bHiColorIcons", "class_c_chi_sq_app.html#a7691e5b612a311bd7caa8fc8eb7e9256", null ],
    [ "m_nAppLook", "class_c_chi_sq_app.html#ae778c0e491835a5b92218a67dda7cf39", null ]
];