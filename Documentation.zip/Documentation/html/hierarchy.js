var hierarchy =
[
    [ "ChiSquare", "class_chi_square.html", null ],
    [ "DiscreteGenerator", "class_discrete_generator.html", [
      [ "DichotomyDG", "class_dichotomy_d_g.html", null ],
      [ "InverseFunctionDG", "class_inverse_function_d_g.html", null ]
    ] ],
    [ "Distribution", "class_distribution.html", [
      [ "DiscreteDistribution", "class_discrete_distribution.html", null ]
    ] ]
];