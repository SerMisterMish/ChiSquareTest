#pragma once
#include <random>
#include <chrono>
extern std::default_random_engine global_rne;