﻿#include "ChiSquare.h"
#include "DichotomyDG.h"
#include "DiscreteDistribution.h"
#include "DiscreteGenerator.h"
#include "Distribution.h"
#include "InverseFunctionDG.h"
#include <chrono>
#include <iostream>
#include <random>

std::default_random_engine global_rne(std::chrono::system_clock::now().time_since_epoch().count());

int main()
{
    using std::cout, std::cin, std::endl;

    // DiscreteDistribution class

    // Creates a uniform discrete distribution with 7 states, this constructor is
    // explicit
    DiscreteDistribution dd1(7);

    const double *probs = dd1.GetProbabilities();
    size_t n = dd1.GetStatesNumber();
    cout << "Probabilities of the uniform discrete distribution dd1 with " << n << " states:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // Creates a discrete distribution from the initializer list, this constructor
    // is explicit
    DiscreteDistribution dd2{0.1, 0.4, 0.2, 0.15, 0.05, 0.1};

    probs = dd2.GetProbabilities();
    n = dd2.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd2 initialized with the "
            "initializer list with "
         << n << " states:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // Changes the probabilities of the dd2 distribution by

    // 1) Copying probabilities
    size_t n_changed{3};
    double *probs_changed = new double[n_changed]{0.5, 0.4, 0.1};
    dd2.SetProbabilities(probs_changed, n_changed);

    delete[] probs_changed;
    probs_changed = nullptr;
    probs = dd2.GetProbabilities();
    n = dd2.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd2 with " << n
         << " states after changing the probabilities by copying:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // 2) Moving the probabilities
    n_changed = 4;
    probs_changed = new double[n_changed]{0.05, 0.7, 0.05, 0.2};
    dd2.SetProbabilitiesM(probs_changed, n_changed);

    probs = dd2.GetProbabilities();
    n = dd2.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd2 with " << n
         << " states after changing the probabilities by moving:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n';

    cout << "probs_changed after moving: " << probs_changed << '\n' << endl;

    // 3) Copying the probabilities of the same size
    // more effective than copying the probabilities of the same size by
    // performing method from 1st case
    n = dd2.GetStatesNumber();
    probs_changed = new double[n]{0.1, 0.2, 0.3, 0.4};
    dd2.SetProbabilitiesSameSize(probs_changed);

    delete[] probs_changed;
    probs_changed = nullptr;
    probs = dd2.GetProbabilities();
    n = dd2.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd2 with " << n
         << " states after changing the probabilities by copying (same size "
            "case):\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // 4) Moving the probabilities of the same size
    // same effectiveness as in 2nd case, but no need to specify the size
    n = dd2.GetStatesNumber();
    probs_changed = new double[n]{0.4, 0.1, 0.1, 0.4};
    dd2.SetProbabilitiesSameSizeM(probs_changed);
    probs = dd2.GetProbabilities();
    n = dd2.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd2 with " << n
         << " states after changing the probabilities by moving (same size "
            "case):\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n';

    cout << "probs_changed after moving: " << probs_changed << '\n' << endl;

    // Probabilities constructor
    n = 4;
    probs = new const double[n]{0.3, 0.4, 0.2, 0.1};
    DiscreteDistribution dd3(probs, n);
    delete[] probs;

    probs = dd3.GetProbabilities();
    n = dd3.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd3 with " << n
         << " states constructed with a probabilities array:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // Move operator

    dd3 = std::move(dd1);
    probs = dd3.GetProbabilities();
    n = dd3.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd3 with " << n << " states after using the move operator:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    probs = dd1.GetProbabilities();
    n = dd1.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd1 with " << n << " states after using the move operator:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // Copy operator

    dd1 = dd2;
    probs = dd1.GetProbabilities();
    n = dd1.GetStatesNumber();
    cout << "Probabilities of the discrete distribution dd1 with " << n << " states after using the copy operator:\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // DiscreteGenerator class and its heirs DichotomyDG and InverseFunctionDG

    size_t sample_size{10};
    DiscreteGenerator *dg1 = new DichotomyDG(dd1, sample_size), *dg2 = new InverseFunctionDG(dd2, sample_size);

    cout << "dg1 distribution:\n";
    probs = dg1->GetDistribution().GetProbabilities();
    n = dg1->GetDistribution().GetStatesNumber();
    cout << n << " states\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    cout << "dg2 distribution:\n";
    probs = dg2->GetDistribution().GetProbabilities();
    n = dg2->GetDistribution().GetStatesNumber();
    cout << n << " states\n";
    for (size_t i{}; i < n; ++i)
    {
        cout << probs[i] << ' ';
    }
    cout << '\n' << endl;

    // Generating one value:
    cout << "A random value generated using dichotomy method: " << dg1->GetRandomValue()
         << "\nusing inverse function method: " << dg2->GetRandomValue() << endl;

    // Generating a sample:
    dg1->Simulate();
    dg2->Simulate();
    auto sample1 = dg1->GetSample(), sample2 = dg2->GetSample();
    size_t sample1_size = dg1->GetSampleSize(), sample2_size = dg2->GetSampleSize();
    size_t states_n1 = dg1->GetDistribution().GetStatesNumber(), states_n2 = dg2->GetDistribution().GetStatesNumber();
    cout << "A sample, generated by dichotomy method of size " << sample1_size << ":\n";
    for (size_t i{}; i < states_n1; ++i)
    {
        cout << sample1[i] << ' ';
    }
    cout << "\nA sample, generated by inverse function method of size " << sample2_size << ":\n";
    for (size_t i{}; i < states_n2; ++i)
    {
        cout << sample2[i] << ' ';
    }
    cout << "\n" << endl;

    // Checking generator type
    cout << "dg1 is a ";
    switch (dg1->GetGenType())
    {
    case DiscreteGenerator::generator_type::DICHOTOMY:
        cout << "Dichotomy method generator\n";
        break;
    case DiscreteGenerator::generator_type::INVERSE_FUNCTION:
        cout << "Inverse function method generator\n";
        break;
    case DiscreteGenerator::generator_type::UNDEF:
        cout << "Undefined generator\n";
        break;
    }

    delete dg1, dg2;

    // ChiSquare class

    dd1 = DiscreteDistribution(4), dd2 = DiscreteDistribution{0.1, 0.2, 0.3, 0.4};
    dg1 = new DichotomyDG(dd1, 100), dg2 = new InverseFunctionDG(dd2, 100);
    dg1->Simulate();
    dg2->Simulate();
    sample1 = dg1->GetSample();
    sample2 = dg2->GetSample();
    probs = dd2.GetProbabilities();
    n = dd2.GetStatesNumber();

    // Constructor with a generator and a distribution, H0 = H1
    ChiSquare chisqtest1(dg1, dd1);

    // Constructor with a sample and a distribution, H0 = H1
    ChiSquare chisqtest2(sample2, dd2);

    // Constructor with a generator and a distribution as a probabilities array,
    // H0 = H1
    ChiSquare chisqtest3(dg2, probs);

    // Constructor with a sample and a distribution as a probabilities array, H0
    // != H1
    ChiSquare chisqtest4(sample1, probs, n);

    // Statistics and p-values:
    cout << "1st test: t = " << chisqtest1.GetCriterion() << ", p = " << chisqtest1.GetPValue() << '\n'
         << "2nd test: t = " << chisqtest2.GetCriterion() << ", p = " << chisqtest2.GetPValue() << '\n'
         << "3rd test: t = " << chisqtest3.GetCriterion() << ", p = " << chisqtest3.GetPValue() << '\n'
         << "4th test: t = " << chisqtest4.GetCriterion() << ", p = " << chisqtest4.GetPValue() << '\n'
         << endl;

    // Generating a new sample and calculating new criterion and p-value (only if
    // a generator was given in constructor)
    chisqtest1.CalculateStatistic();
    chisqtest3.CalculateStatistic();
    cout << "New statistics and p-values for\n1st test: t = " << chisqtest1.GetCriterion()
         << ", p = " << chisqtest1.GetPValue() << '\n'
         << "3rd test: t = " << chisqtest3.GetCriterion() << ", p = " << chisqtest3.GetPValue() << '\n'
         << endl;

    // Changing sample size for a generator (only if it was given)
    size_t new_smple_size{200};
    chisqtest1.ChangeSampleSize(new_smple_size);
    cout << "1st test after changing the sample size: t = " << chisqtest1.GetCriterion()
         << ", p = " << chisqtest1.GetPValue() << '\n'
         << endl;

    delete dg1, dg2;
}
