//{{NO_DEPENDENCIES}}
// ���������� ����, ��������� � Microsoft Visual C++.
// ������������ ChiSq.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_ChiSqTYPE                   130
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        205
#define ID_VIEW_APPLOOK_OFF_XP          206
#define ID_VIEW_APPLOOK_WIN_XP          207
#define ID_VIEW_APPLOOK_OFF_2003        208
#define ID_VIEW_APPLOOK_VS_2005         209
#define ID_VIEW_APPLOOK_VS_2008         210
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define ID_VIEW_APPLOOK_WINDOWS_7       219
#define IDS_EDIT_MENU                   306
#define IDD_SETTINGS                    310
#define IDC_PROBABILITIES_H0            1000
#define IDC_STATES_H0                   1001
#define IDC_DTYPE_A_H0                  1002
#define IDC_DTYPE_U_H0                  1003
#define IDC_PROBABILITIES_H1            1004
#define IDC_DTYPE_A_H1                  1006
#define IDC_DTYPE_U_H2                  1007
#define IDC_METHOD_IF                   1008
#define IDC_METHOD_DICHOTOMY            1009
#define IDC_SAMPLE_SIZE                 1010
#define IDC_BUTTON_RAND_H0              1011
#define IDC_PVSIZE                      1012
#define IDC_BUTTON_RAND_H1              1013
#define IDC_POWER_TEST_BOT              1014
#define IDC_POWER_TEST_TOP              1015
#define IDC_POWER_TEST_SL               1016
#define ID_BUTTON_HIST                  32777
#define ID_HISTOGRAM                    32778
#define ID_SETTINGS                     32780
#define ID_P                            32781
#define ID_PVDF                         32782
#define ID_POWERLEVELONSAMPLESIZE       32791
#define ID_BUTTON32793                  32793

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
